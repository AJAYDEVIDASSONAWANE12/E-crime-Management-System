
	<div class="col-md-12">
		<div class="panel panel-success"style="margin-top:25px">
			<div class="panel-heading" style="background:rgb(99, 201, 201)">
				<center><h3 style="color:black">E-CRIME RECORDS MANAGEMENT SYSTEM</h3></center>

<style>
	body {
    font-family: Arial, sans-serif;
    background: rgb(99, 201, 201);;
    background-size: 400% 400%;
    animation: gradientAnimation 15s ease infinite;
    margin: 0;
    padding: 0;
}
</style>

					
						<?php 
						
						include('session.php');
						include('dbconnect.php');
						
						$query= mysqli_query($dbcon,"select * from userlogin where staffid = '$session_id'")or die(mysql_error());
						$row = mysqli_fetch_array($query);
						
						?>
                            <span class="pull-right" style="margin-top:22px">
                               <?php echo $row['surname']." ". $row['othernames']." (" .$row['staffid'].")";  ?> 
                                 
                                  <a style="font-size:20px"href="profile.php"><i class="icon-signout icon-large" ></i>&nbsp;Edit</a>
                                   <a style="font-size:20px" href="logout.php"><i class="icon-signout icon-large"></i>&nbsp;Logout</a>
                                  </span>
                             
                    </div>




			</div>
			<div class="panel-body">
				<div class="row">
					<div class="col-md-3">
						<div class="panel panel-info">
							<div class="panel-heading">
								<h3 class="panel-title"> <a href="index.php">
									<span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a>
							</div>
							
						</div>
					</div>
					
					

					<div class="col-md-3">
						<div class="panel panel-info">
							<div class="panel-heading">
								<h3 class="panel-title"> <a href="index.php">
									<span class="glyphicon glyphicon-user" aria-hidden="true"></span> View Assigned Cases</a>
							</div>
							
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</div>