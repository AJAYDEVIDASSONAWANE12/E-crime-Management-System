/*
	*	Original script by: Shafiul Azam
	*	ishafiul@gmail.com
	*	Version 3.0
	*	Modified by: Luigi Balzano

	*	Description:
	*	Inserts Countries and/or States as Dropdown List
	*	How to Use:

		In Head section:
		<script type= "text/javascript" src = "countries.js"></script>
		In Body Section:
		Select Country:   <select onchange="print_state('state',this.selectedIndex);" id="country" name ="country"></select>
		<br />
		City/District/State: <select name ="state" id ="state"></select>
		<script language="javascript">print_country("country");</script>	

	*
	*	License: OpenSource, Permission for modificatin Granted, KEEP AUTHOR INFORMATION INTACT
	*	Aurthor's Website: http://shafiul.progmaatic.com
	*
*/

var country_arr = new Array("Jalgaon", "Dhule","nashik","Mumbai","Akola","Amravati","Nagpur","Nanded","Buldhana","Beed","Hingoli","Washim","Pune","Jalna","Chh.SambhajiNagar");
var s_a = new Array();
s_a[0]="";
s_a[1]=
"Muktainagar|Bhusawal|Amalner|Dharangaon|Chopada|Jamner|Pachora|Erandol|Raver|Yawal|Chalisgaon|Faizpu";
s_a[2]="Dhule| Sakri| Shirpur|Shindkheda";
s_a[3]="Nashik|Igatpuri| Trimbakeshwar|Dindori| Peth| Kalwan| Surgana| Chandwad| Deola| Baglan (Satana)|Malegaon|Nandgaon| Yeola| Niphad| Sinnar";
s_a[4]="Andheri| Borivali|Kurla";
s_a[5]="Akola|Akot|Telhara|Balapur|Patur|Murtijapur|Barshitakli";
s_a[6]="Amravati|Bhatkuli|Nandgaon|Dharni|Chikhaldara|Achalpur|Chandurbazar|Morshi|Warud|Daryapur|Chandur|Dhamangaon|Tiosa";
s_a[7]="Nagpur|Kamptee|Hingna|Katol|Narkhed|Savner|Kalmeshwar|Ramtek|Mouda|Parseoni|Umred|Kuhi|Bhiwapur";
s_a[8]="Nanded|Ardhapur|Mudkhed|Bhokar|Umri|Loha|Kandhar|Kinwat|Himayatnagar|Hadgaon|Mahur|Deglur|Naigaon";
s_a[9]="Buldhana|Chikhli|Deulgaon Raja|Jalgaon Jamod|Sangrampur|Malkapur|Motala|Nandura|Khamgaon|Shegaon|Mehkar|Lonar";
s_a[10]="Beed|Ashti|Patoda|Shirur-kasar|Georai|Majalgaon|Wadwani|Kaij|Dharur|Parli|Ambajogai";
s_a[11]="Hingoli|Sengaon|Kalamnuri|Basmath|Aundha Nagnath";
s_a[12]="Washim|Malegaon|Risod|Mangrulpir|Karanja|Manora";
s_a[13]="Pune|Haveli|Khed|Junnar|Ambegaon|Maval|Mulshi|Shirur|purandhar|Velhe|Bhor|Baramati|Indapur|Daund";
s_a[14]="Jalna|Bhokardan|Jafrabad|Badnapur|Ambad|Ghansawangi|Partur|Mantha";
s_a[15]="Chh. SambhajiNagar|Kannad|Soegaon|Sillod|Phulambri|Khuldabad|Vaijapur|Gangapur|Paithan";

function print_country(country_id){
	// given the id of the <select> tag as function argument, it inserts <option> tags
	var option_str = document.getElementById(country_id);
	option_str.length=0;
	option_str.options[0] = new Option('Select Region','');
	option_str.selectedIndex = 0;
	for (var i=0; i<country_arr.length; i++) {
		option_str.options[option_str.length] = new Option(country_arr[i],country_arr[i]);
	}
}

function print_state(state_id, state_index){
	var option_str = document.getElementById(state_id);
	option_str.length=0;	// Fixed by Julian Woods
	option_str.options[0] = new Option('Select District','');
	option_str.selectedIndex = 0;
	var state_arr = s_a[state_index].split("|");
	for (var i=0; i<state_arr.length; i++) {
		option_str.options[option_str.length] = new Option(state_arr[i],state_arr[i]);
	}
}
