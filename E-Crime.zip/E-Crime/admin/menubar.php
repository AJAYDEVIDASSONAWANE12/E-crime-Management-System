
	<div class="col-md-12" style="margin-top:20px">
		<div class="panel panel-success" style="background: rgb(99, 201, 201)">
			<div class="panel-heading"style="background: rgb(99, 201, 201)" style="padding-bottom: 40px;">
				<center><h1 style="color:black">E-CRIME RECORDS MANAGEMENT SYSTEM</h1></center>

				<style>
					body {
    font-family: Arial, sans-serif;
    background: rgb(99, 201, 201);
    background-size: 900% 400%;
    animation: gradientAnimation 15s ease infinite;
    margin: 0;
    padding: 0;
}

				</style>


					
						<?php 
						
						include('session.php');
						include('dbconnect.php');
						
						$query= mysqli_query($dbcon,"select * from userlogin where staffid = '$session_id'")or die(mysqli_error());
						$row = mysqli_fetch_array($query);
						
						?>
                            <span class="pull-right" style="margin-top: 22px;">
                               <?php echo $row['surname']." ". $row['othernames']." (" .$row['staffid'].")";  ?> 
                                 
                                  <a  style="font-size:20px" href="profile.php"><i class="icon-signout icon-large"></i>&nbsp;Edit</a>
                                   <a  style="font-size:20px"href="logout.php"><i class="icon-signout icon-large"></i>&nbsp;Logout</a>
                                  </span>
                             
                    </div>




			</div>
			<div class="panel-body" >
				<div class="row"style="">
					<div class="col-md-3"style="margin-top: 65px">
						<div class="panel panel-info">
							<div class="panel-heading">
								<h3 class="panel-title"> <a href="index.php">
									<span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a>
							</div>
							
						</div>
					</div>
					
					<div class="col-md-3"style="margin-top: 65px">
						<div class="panel panel-info">
							<div class="panel-heading">
								<h3 class="panel-title"> <a href="addstaff.php">
									<span class="glyphicon glyphicon-plus" aria-hidden="true"></span>
  
									Add Staff</a>
								
								</h3>
							</div>
							
						</div>
					</div>
					<div class="col-md-3"style="margin-top: 65px">
						<div class="panel panel-info">
							<div class="panel-heading">
								<h3 class="panel-title"> <a href="user.php">
									<span class="glyphicon glyphicon-plus" aria-hidden="true"></span>
  
									View Staff</a>
								
								</h3>
							</div>
							
						</div>
					</div>
					<div class="col-md-3"style="margin-top: 65px">
						<div class="panel panel-info">
							<div class="panel-heading">
								<h3 class="panel-title"> <a href="caseview.php">
									<span class="glyphicon glyphicon-plus" aria-hidden="true"></span>
  
									View Cases</a>
								
								</h3>
							</div>
							
						</div>
					</div>
					

					
					
				</div>
			</div>
		</div>
	</div>