<?php 

include('header.php');

 ?>


<style>
	.dashboard {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 20px;
      margin: 40px auto;
      max-width: 1000px;
    }

    .card {
      background-color: #ffffffaa;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 2px 2px 8px rgba(0, 0, 0, 0.15);
    }

    .card h2 {
      margin-top: 0;
    }

    .footer {
      text-align: center;
      margin-top: 50px;
      color: #222;
    }
</style>

<div  class="container-fluid" style="margin-top:40px">
	<?php include('menubar.php')?>
	<div class="col-md-1"></div>
</div>
<!--
<div class="container-fluid">
	<div class="col-md-2"></div>
	<div class="col-md-8">
		<div class="panel panel-inverse">
			<div class="panel-body">
			 <h2 >
			 E-Crime Record Management Portal
			 </h2>
			 
				
			</div>
		</div>
	</div>
	<div class="col-md-2"></div>
</div> -->
<div class="dashboard">
    <div class="card">
      <h2>📊 Case Statistics</h2>
      <p>Total Cases: 120</p>
      <p>Open Cases: 45</p>
      <p>Closed Cases: 75</p>
    </div>

    <div class="card">
      <h2>🕵️‍♂️ Staff Overview</h2>
      <p>Total Staff: 25</p>
      <p>On Duty: 20</p>
      <p>Off Duty: 5</p>
    </div>

    <div class="card">
      <h2>📅 Recent Activity</h2>
      <ul>
        <li>Case #233 updated</li>
        <li>New staff added: Inspector R. Mehta</li>
        <li>Case #229 closed</li>
      </ul>
    </div>

    <div class="card">
      <h2>📌 Notices</h2>
      <ul>
        <li>System maintenance on April 20</li>
        <li>Meeting scheduled at 11 AM tomorrow</li>
        <li>Training session next week</li>
      </ul>
    </div>
  </div>

  <div class="footer">
    &copy; 2025 E-Crime Management. All rights reserved.
  </div>

<?php include('scripts.php'); ?>

</body>
</html>